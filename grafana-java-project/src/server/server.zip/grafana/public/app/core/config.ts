import { config, GrafanaBootConfig } from '@grafana/runtime';

// Legacy binding paths
export { config, GrafanaBootConfig as Settings };
export default config;
